#ifndef MENU_H
#define MENU_H
#include <QDebug>
#include <QMainWindow>
#include "personnel.h"
#include "conge.h"
#include "departement.h"
#include <QWidget>
//#include <QSound>
namespace Ui {
class menu;
}

class menu : public QMainWindow
{
    Q_OBJECT

public:
    explicit menu(QWidget *parent = nullptr);
    ~menu();
private slots:
    void on_ajouterpersonnel_clicked();

    void on_ajouterconge_clicked();

    void on_modifierdepartement_clicked();

    void on_ajouterdepartement_clicked();

    void on_supprimerdepartement_clicked();

    void on_pushButton_supp_clicked();

    void on_modifperso_clicked();

    void on_modifierconge_clicked() ;

    void on_supprimerconge_clicked();

    void on_refresh1_clicked();
    void on_refresh2_clicked();
    void on_refresh3_clicked();
    void on_chercher_clicked();
    void on_chercherconge_clicked();
    void on_chercherdepart_clicked();




    void on_departement_currentTextChanged(const QString &arg1);

private:
    Ui::menu *ui;
    personnel tmpp;
    conge tmpc;
    departement tmpd;
    //QSound *son;
};

#endif // MENU_H


